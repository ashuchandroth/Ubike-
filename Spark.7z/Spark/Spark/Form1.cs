﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spark
{
    public partial class Form1 : Form
    {
        int points = 0;
        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(133, 217, 94);
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void distanceBox_TextChanged(object sender, EventArgs e)
        {
            int number;

            if (Int32.TryParse(distanceBox.Text, out number))
            {
                label6.Text = "$" + (Double.Parse(distanceBox.Text) * 0.25).ToString();
                total.Text = "$"+((Double.Parse(distanceBox.Text) * 0.25)+2.00).ToString();
            }
            else
            {
                label6.Text = "$0.00";
                total.Text = label5.Text;
            }
            


          
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int number;
            if (Int32.TryParse(distanceBox.Text, out number))
            {
                points += Int32.Parse(distanceBox.Text) / 10;
                label8.Text = points.ToString();
                distanceBox.Text = String.Empty;
                if (points >= 100)
                {
                    MessageBox.Show("Congratulations! You nave earned a free one month gym membership!");
                    points -= 100;
                    label8.Text = points.ToString();
                }
            }
            else
            {
                points += 0;
            }
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            pictureBox1.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            panel1.Visible = true;
            pictureBox3.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox1.Visible = true;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            panel1.Visible = false;
            pictureBox1.Visible = false;
            pictureBox3.Visible = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
